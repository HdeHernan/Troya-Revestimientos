# Troya Revestimientos — portfolio web

Sitio estático hecho con HTML, CSS y JavaScript, sin base de datos ni dependencias.

## Abrir en local
1. Descomprimí el proyecto.
2. Abrí la carpeta en Visual Studio Code.
3. Abrí `index.html` en el navegador. Para trabajar cómodamente, podés usar la extensión Live Server.

## Datos de contacto ya configurados
- Instagram: https://www.instagram.com/troya.revestimientos/
- WhatsApp: enlace internacional configurado para el número indicado, con mensaje inicial.

## Agregar las fotos reales
Guardá tus imágenes en `assets/images/` con estos nombres:
- `trabajo-01.jpg`
- `trabajo-02.jpg`
- `trabajo-03.jpg`
- `trabajo-04.jpg`
- `trabajo-05.jpg`
- `trabajo-06.jpg`

Los archivos deben coincidir exactamente con esos nombres. Si tus imágenes son PNG o WebP, también podés cambiar la extensión en los `src` de `index.html`. Antes de publicar, revisá que todas las fotos se vean correctamente. Conviene reducir imágenes demasiado pesadas para mejorar la velocidad.

## Agregar un video
En `index.html` buscá la sección `VIDEOS`. Hay un ejemplo comentado de iframe para YouTube. Reemplazá `ID_DEL_VIDEO` por el identificador del video y sustituí el bloque de ejemplo por el iframe.

## Publicar gratis con GitHub Pages
1. Creá un repositorio nuevo en GitHub.
2. Subí todos los archivos del proyecto; `index.html` debe quedar en la raíz.
3. Abrí **Settings → Pages**.
4. En **Build and deployment**, elegí **Deploy from a branch**.
5. Seleccioná la rama `main` y la carpeta `/(root)`, y guardá.
6. Esperá a que aparezca la URL publicada en la sección Pages.

## Checklist antes de publicar
- [ ] Reemplazar las seis imágenes por fotos reales.
- [ ] Confirmar que WhatsApp abra la conversación correcta.
- [ ] Confirmar que Instagram abra el perfil correcto.
- [ ] Probar en celular y computadora.
- [ ] Comprobar que no haya imágenes faltantes.
- [ ] Revisar los textos y servicios para que reflejen exactamente lo que ofrece el negocio.
